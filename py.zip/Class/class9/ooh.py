student1 ={
    'name':'tara',
    'roll':123
}

student2={
    'name':'shiva'
}

student3={
    'name':"robot"
}

student={
    'student1':student1,
    "student2":student2,
    'student3':student3
}

print(student)