a={
    "A":"handsome",
    'B':"Ball",
    'C':'hope'
}
a['A']="Shiva"
a.update()
print(a)