girl=[]
n=int(input("Enter the value of n="))

print("++++++++++++++++++++enter the girl name==+++++++++++++++++++++++++++++\n")
for i in range(n):
    girls=input("")
    girl.append(girls)

    
print("==================Check====================")
if "tara" in girl:
    print("yes")
else:
    print("no")        
