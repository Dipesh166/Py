#remove
a=["dog",12,25.5,"dog", "dog"]
n=a.count("dog")


for i in range(n):
    a.remove("dog")


    print(a)

