fruits=['apple','bananan','tomato',"apple","apple"]
a=[]

for i in fruits:
    if"a" in i:
        fruits.remove(i)

print(fruits)
