num=[100,500,600,700,500,5000,50000000000,8,5,9000]
maxi=max(num)
mini=min(num)
print(maxi)
print(mini)