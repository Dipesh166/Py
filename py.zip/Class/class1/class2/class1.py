a=5
a+=500
b=6
print(a)
b-=500
print(b)
