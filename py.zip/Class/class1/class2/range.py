student ="students"
n = int (inpput)