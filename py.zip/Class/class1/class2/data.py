a=20
b=20.5
c='dipesh'
d=False
print(type(a))
print(type(b))
print(type(c))
print(type(d))