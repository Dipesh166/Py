student=['ram','harry','ppoja']

student[1:2]=["sita"]
 
print(student)

student[2:]=["radha",'tags','joo']
print(student)