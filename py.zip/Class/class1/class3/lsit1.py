#user defined list
name =[]
n = int(input("ENTER THE NAME OF THE DEVICE \n"))
for i in range (n):
    nameh=input("ENTER THE NAME==")
    name= name+[nameh]

    print(name)



