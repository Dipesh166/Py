fruits=['apple','banana']
n=int(input("Enter the value of n="))

for i in range(n):
    fruit=input("enter the fruit name==")
    fruits.append(fruit)

    print(fruits)

    