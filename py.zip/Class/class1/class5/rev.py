# reverse in the list
animal=['dog','cat','tiger']
print(animal)
animal.reverse()
print(animal)