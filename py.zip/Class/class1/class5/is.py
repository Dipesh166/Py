a=[[[[],[]],[[],[]]],[[[],[]],[[],[]]],[[[],[]],[]]]
print(type(a))
print(len(a))


b=[[1,2,3],['oohoh'],['gangam']]
print(b[2][0])