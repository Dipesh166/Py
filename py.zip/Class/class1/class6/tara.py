a=("tara","sitara","madamji","asleye","sauravi")
if "asleye" in a:
    print("yes asleye is there")
else:
    print("not found")