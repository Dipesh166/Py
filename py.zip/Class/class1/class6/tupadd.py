a=("book","shoes")
b=("loose","mangoose")
a+=b
print(a)
