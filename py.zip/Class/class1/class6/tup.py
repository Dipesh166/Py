#user definess
a=()
n=int(input("enter the range for tuple"))
for i in range(n):
    b=int(input("enter the tuple value=="))
    a=a+(b,)

print(a)
