# example of the boolean
def show():
    a=input("ENTER THE VALUE=")
    print(isinstance(a,int))

show()




