for i in range(100001):
    print(i)