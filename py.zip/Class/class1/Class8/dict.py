a={
    "name":"dipesh",
    "level":"40",
    "game":"ml,food,wallet"
}

print(a)