name=input("ente name=")
age=int(input("Enter age="))
info="hello  " + name + " my age is " + str(age)
print(info)