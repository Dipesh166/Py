# global variable

add=int(input("enter the value add"))
sub=int(input("enter the value subb"))


def given():
    a=int(input("enter the value"))
    b=int(input("Enter the value of the b"))
    c=a+b
    print(c)


def mult():
    
    go=add*sub
    print(go)

    

given()
mult()
