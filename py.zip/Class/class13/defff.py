def heoo():
    print("Heloo World")

heoo()