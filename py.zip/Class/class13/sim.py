# function with no arguments and return types


def simp():
    p=int(input("enter the principle"))
    t=int(input("enter the time"))
    r=int(input("enter the rate"))

    s=p*t*r/100
    print("THE VALUE IS ::",s)


simp()