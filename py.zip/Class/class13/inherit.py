# Single inheritance
 #dipesh kumar mandal utsav singh is very creative
class A:
   def show_detail(self):
    print("I love nepal")

class B(A):
    def see_det(self):
        print("i love usa")




e=A()
f=B()
e.show_detail()
f.see_det()
f.show_detail()
    
